Documentation in directory "docs" and https://openbadges.luisgf.es/

