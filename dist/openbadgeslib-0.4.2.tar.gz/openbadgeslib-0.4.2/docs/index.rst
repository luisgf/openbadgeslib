.. OpenBadgesLib documentation master file, created by
   sphinx-quickstart on Wed Mar 11 08:43:53 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to OpenBadgesLib's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   installation
   development
   authors
   userguide
   glossary

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

