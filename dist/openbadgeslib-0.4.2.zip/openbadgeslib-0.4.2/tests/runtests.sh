#!/bin/sh

python3.4 -m unittest discover -p "test_*.py" $*

