Authors
=======

Contributors
------------

Sorted alphabetically:

* Jesús Cea Avión <jcea@jcea.es>
* Luis González Fernández <luisgf@luisgf.es>
  
License
-------  

This library is licensed under the terms of the :term:`LGPL3` and the wrapper tools under the terms of :term:`BSD 2-Clause` 
license. That’s let you the freedom to do that you need with both.
      
